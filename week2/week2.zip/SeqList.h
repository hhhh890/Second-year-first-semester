#include <iostream>
#include <stdlib.h>
#include "LinearList.h"
const int defaultSize = 100;
template <class T>  
class SeqList : public LinearList<T>{
protected:
      T *data;                               //˳����洢����
      int maxSize;                         //�����������	
      int last; 	                   //��ǰ���Ԫ���±�
      void reSize(int newSize){
            if(newSize <= 0) {std::cout<<"�¿ռ䲻��С�ڵ���0"<<std::endl; return;}
            if(newSize != maxSize){
                T* newData = new T[newSize];
                if(newData == NULL) {std::cout<<"�洢�������"<<std::endl; exit(1);}
                int n = (last+1 < newSize)? last+1 : newSize;
                for(int i=0; i<n; i++) newData[i] = data[i];
                delete [] data;
                data = newData;
                maxSize = newSize;
                if(last >= maxSize) last = maxSize -1;
            }
      };      //�����ռ��С
public:
      SeqList ( int sz = defaultSize ): maxSize(sz), last(-1)
         { data = new T[maxSize]; if (data == NULL)
            { std::cout << "�洢�������" << std::endl; exit(1); } }
      SeqList (SeqList<T>& L ):maxSize(L.Size()),last(L.Length()){
        data = new T[maxSize];
        if(data == NULL) {std::cout<<"�洢�������"<<std::endl; exit(1);}
        for(int i=0; i<=last; i++) data[i] = L.data[i];
      };
      ~SeqList ( ) { delete[ ] data; }
      int Size( ) const { return maxSize; }
      int Length( ) const { return last+1; }	
       int Search ( T x ) const{
            for ( int i = 0; i <= last; i++ )
                if ( data[i] == x ) return i + 1;
            return 0;
       };        //����
        int Locate ( int i ) const{ return (i < 1 || i > last+1) ? 0 : i-1; }
        bool getData ( int i , T&x) const     //ȡ��i��ֵ
            { if(i > 0 && i <= last + 1)  {x = data[i- 1];  return true; } else return false; }
        bool setData ( int i, T x )   //���i��ֵ
            {if (i > 0 && i <= last + 1) {data[i- 1] = x;  return true;}  else return false; }
        bool Insert ( int i, T x){
            if (i < 1 || i > last + 2) return false;
            if((*this).IsFull()){
                (*this).reSize(maxSize*2);
            }
            T temp = data[i-1];
            data[i-1] = x;
            for (auto j = i; j <=last+1; j++)
            {
                T t = data[j];
                data[j] = temp;
                temp = t;
            }
            last +=1;
            return true;
        };           //����
        bool Remove ( int i, T& x){
            if(i < 1 || i > last + 1) return false;
            if(last==-1) return false;
            x = data[i-1];
            for (int j = i; j <= last; j++)
                data[j-1] = data[j];
            last -= 1;
            return true;

        };    //ɾ��
        bool IsEmpty ( ) const{ return (last ==-1) ; }
        bool IsFull ( ) const { return (last == maxSize-1) ; }
        SeqList<T>& operator = (SeqList<T>& L ){
            if(this != &L){
                delete [] data;
                maxSize = L.Size();
                last = L.Length();
                data = new T[maxSize];
                if(data == NULL) {std::cout<<"�洢�������"<<std::endl; exit(1);}
                for(int i=0; i<=last; i++) data[i] = L.data[i];
            }
            return *this;
        }
        T& operator [](int i){
            if(i<0 || i>last) {std::cout<<"�±�Խ��"<<std::endl; exit(1);}
            return data[i];
        }
 }	 ;
