 #include<iostream>
 using namespace std;
template <class T>	
struct LinkNode {	
    T data;                         //������� 
    LinkNode<T> *link;    //�������ָ��
    LinkNode ( LinkNode<T> *ptr = NULL )
    {link = ptr; } 	
    LinkNode ( const T& item, LinkNode<T> *ptr = NULL ) 
    { data = item, link = ptr; }
}; 

template<typename T>
 class List { //������		
    public: 
        LinkNode<T> *first;            //��ͷָ��
        List (  ) { first = new LinkNode<T>; }
        List(const T& x){first = new LinkNode<T>(x);}
        List(const List<T>& l){
            first = new LinkNode<T>(l.first->data);
            LinkNode<T>* curr = l.first->link;
            LinkNode<T>* last = first;
            while (curr!=nullptr)
            {
                LinkNode<T> cop = new LinkNode<T>(curr->data);
                last->link = cop;
                curr = curr->link;
                last = cop;
                /* code */
            }
            
        }
        ~List(){
            makeEmpty();
            delete first;
        }

        //��ҵ2 ���ʵ��
        LinkNode<T>* isRound(){
            LinkNode<T>* fast,*slow,*entry;
            fast = slow = entry = first;
            
            while (fast!=nullptr&& fast->link != nullptr)
            {
                fast = fast->link->link;
                slow = slow->link;

                if (fast==slow)
                {
                    //�ƻ���entry
                    while (entry!=slow)
                    {
                        entry = entry->link;
                        slow = slow->link;
                        /* code */
                    }
                    
                    return entry;
                }
                /* code */
            }
            return nullptr;
            
        }



        void makeEmpty(){
            LinkNode <T> *q;
            while ( first->link != NULL ) {
                q = first->link;  
                    first->link = q->link;
                delete q;          //�ͷ�
            }
        }
        bool Insert( int i, T x ){    
            LinkNode<T>* newNode = new LinkNode<T>(x);
            if (newNode == nullptr) {  cout <<"�洢�������\n "; exit(1); }
            if ( first == nullptr || i == 0 ) {    //���ڱ�ǰ
                newNode->link = first;		first = newNode;
            }
            else {
                LinkNode<T> *current = first;
                for (int k = 1; k < i; k++ )  //�ҵ� i�����
                    if ( current == nullptr ) break;   else current = current->link; 
                if ( current == nullptr )   
                {  cerr << "��Ч�Ĳ���λ��!\n "; delete newNode; return false; }    
                else
                { newNode->link = current->link;    current->link = newNode; }
            }
            return true;						
        }
        bool  Remove (int i, T &x ){
            LinkNode<T>* curr,del;
            if (i<=1)
            {
                del = first;
                first = first->link; 
            }
            else{
                curr = first;
                for (size_t j = 0; j < i; j++)
                {
                    if (curr == nullptr) break;      
                    else curr = curr->link;
                }
                if (curr==nullptr)
                {
                    cout<<"ɾ����Чλ��"<<endl;
                    return false;
                    /* code */
                }
                else{
                    del = curr;
                    curr = curr->link;
                }
            }
            x = del->data;
            delete del;
            return true;
        }                 //������������
        int Length()const{
            //����������
            LinkNode<T>* p = first->link;
            int count = 0;
            while (p!=nullptr)
            {
                p = p->link;
                count++;
                /* code */
            }
            return count;
        }
        List<T>& operator = ( List<T>& L ){
            if (this!=&L)
            {
                LinkNode<T>* curr = L.first;
                LinkNode<T>* cop = first = new LinkNode<T>;
                while (curr!=nullptr)
                {
                    cop->link = new LinkNode<T>(curr->data);
                    curr = curr->link;
                    cop = cop->link;
                    /* code */
                }
                return *this;
                /* code */
            }
            return *this;
        }
        void  inputFront(T endTag) {
            T val;   LinkNode<T> *newNode; 
            makeEmpty();    
            while ( cin >> val ) {
                newNode = new LinkNode<T>(val);
                if (newNode == NULL) 
                {cerr<<"�洢�������"<<endl; exit(1);}
                newNode->link = first->link;
                first->link = newNode;    //���뵽��ǰ��
                // cin >> val;
            }
        } 

        void inputRear() {
            T val;   LinkNode<T> *newNode, *last; 
            makeEmpty();
              last = first; 
            while ( cin >> val) {       //lastָ���β
                newNode = new LinkNode<T>(val);
                if (newNode == NULL) 
                {cerr<<"�洢�������"<<endl; exit(1);}
                last->link = newNode;  last = newNode;      
                if (cin.get()=='\n') break;
                //cin >> val;                        //���뵽��ĩ��
            }
            last->link = NULL;               //����β     
        } 

        void output(){
            LinkNode<T>* curr= first->link;
            while (curr!=nullptr)
            {
                cout<<curr->data<<' ';
                curr = curr->link;
                /* code */
            }
            
        }
        
    
       
};

