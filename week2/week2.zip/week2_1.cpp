#include<iostream>
#include "SeqList.h"
using namespace std;
//���������������


int main(){
    SeqList<int> v(50);
    int i;
    cout<<"������һ���������Իس�������"<<endl;
    int count = 1;
    while (cin>>i)
    {
        v.Insert(count,i);
        count++;
        if (cin.get()=='\n') break;
        /* code */
    }
    int maxv,minv;
    if(v.Length()%2){
        maxv = minv = v[0];
    }
    else{
        if(v[0]>v[1]){
            maxv = v[0];
            minv = v[1];
        }
        else{
            maxv = v[1];
            minv = v[0];
        }
    }
    for (int i = v.Length()%2?1:2; i != v.Length(); i+=2)
    {
        if(v[i]>v[i+1]){
            if(v[i] > maxv) maxv = v[i];
            if(v[i+1] < minv) minv = v[i+1];
        }
        else{
            if(v[i+1]>maxv) maxv = v[i+1];
            if(v[i]<minv) minv = v[i];
        }
        /* code */
    }
    cout<<"max: "<<maxv<<endl;
    cout<<"min: "<<minv<<endl;
    return 0;
    
    
}
