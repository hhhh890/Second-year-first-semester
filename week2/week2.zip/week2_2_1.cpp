#include"list.h"
#include<iostream>
using namespace std;

void reverse(List<double>& res){
    LinkNode<double>* prev =nullptr;
    LinkNode<double>* now =res.first->link;
    LinkNode<double>* next = nullptr;
    LinkNode<double>* head = res.first;
    while (now!=nullptr)
    {
        next = now->link;
        now->link = prev;
        prev = now;
        now = next;
    }
    head->link = prev;
}

int main(){
    cout<<"�����һ���ǵݼ���������,�س�����"<<endl;
    List<double> one,twe;
    one.inputRear();
    cout<<"����ڶ����ǵݼ���������,�س�����"<<endl;
    twe.inputRear();
    LinkNode<double>* p1 = one.first->link;
    LinkNode<double>* p2 = twe.first->link;
    List<double> res;
    LinkNode<double>* pres = res.first;
    while (p1!=nullptr && p2!= nullptr){
        if(p1->data<p2->data){
            pres->link = p1;
            p1 = p1->link;
        }
        else{
            pres->link = p2;
            p2 = p2->link;
        }
        pres = pres->link;
    }
    if (p1==nullptr&&p2!=nullptr)
    {
        while (p2!=nullptr)
        {
            pres->link = p2;
            p2 = p2->link;
            pres = pres->link;
            /* code */
        }   
    }
    if (p2 == nullptr)
    {
        while (p1!=nullptr)
        {
            pres->link = p1;
            p1 = p1->link;
            pres = pres->link;
            /* code */
        }
        
        /* code */
    }
    cout<<"res:"<<endl;
    res.output();
    //��ת����
    reverse(res);
    cout<<"reverse res:"<<endl;
    res.output();

    
}
