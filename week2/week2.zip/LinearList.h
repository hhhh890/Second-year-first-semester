template <class T>
class LinearList {
public:
     LinearList ( ){};
     ~LinearList ( ){}; 
     virtual int Size ( ) const = 0; 	       
     virtual int Length ( ) const = 0; 
     virtual bool getData ( int I, T &x ) const = 0;     //取第i项
     virtual  bool setData ( int i, T x ) = 0;              //设第i项
     virtual bool Insert ( int i, T x ) = 0;     
          //插入
    virtual bool Remove ( int i, T& x ) = 0;	//删除
     virtual bool IsEmpty ( ) const = 0; 
     virtual bool IsFull ( ) const = 0; 
     //virtual void Sort ( ) = 0;
     //virtual void input ( ) = 0 ;
     //virtual void output ( ) = 0;
};
